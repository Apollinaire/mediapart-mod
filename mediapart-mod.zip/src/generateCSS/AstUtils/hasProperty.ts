import { Declaration, Rule } from "css-tree";

const hasProperty = (rule: Rule, property: Declaration["property"]) => {
  
}